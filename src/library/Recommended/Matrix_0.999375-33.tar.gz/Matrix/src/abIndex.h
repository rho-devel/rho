#ifndef MATRIX_AbstrINDEX_H
#define MATRIX_AbstrINDEX_H

#include "Mutils.h"

SEXP Matrix_int_rle(SEXP x_);

#endif

